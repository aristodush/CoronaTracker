package io.javabrains.coronavirustracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.Scanner;

@SpringBootApplication
@EnableScheduling
public class CoronavirusTrackerApplication {


    public static void main(String[] args) {SpringApplication.run(CoronavirusTrackerApplication.class, args);}

    /*Scanner scanner = new Scanner(System.in);
        System.out.println("wE WOULD LIKE YOU NAME ENTERED TO CONTINUE");

    String name = scanner.nextLine().toUpperCase();

        System.out.println("WELCOME : " + name);
*/
}
