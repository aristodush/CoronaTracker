package io.javabrains.coronavirustracker.services;

import io.javabrains.coronavirustracker.models.LocationStats; //IMPORTING FROM OUR LOCATION STATS PACKAGE
import org.apache.commons.csv.CSVFormat; //IMPORTING FROM APACHE CSV FORMAT
import org.apache.commons.csv.CSVRecord; //IMPORTING FROM CSV RECORD TO RETRIEVE CSV FILES IN OUR JAVA PROGRAM
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.IOException; //IMPORTING FROM INPUT OUTPUT ERROR EXOEPTIONS
import java.io.StringReader;
import java.net.URI; //IMPORTING UNIFORM RESOURCE IDENTIFIER
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
/* OUR OUTPUT WILL BE PRINTED IN BROWSER TO GATHER INFO FROM WORLD CORONA VIRUS DATA REPORT
* START BY VISITNG spring.io
* import themeleaf, devtool and Spring web
*
* import with Maven Project
* COnfigure JAVAn in porm.vlm and upddate compiler
*Loaded Github DAta CSSEGISandData
* Start with calling in CoronavirusApplication one with Main    (CREATE ENABLE SCHEDULING IN MAIN)
* created service Coronavirus Class
*
* cREATE MODEL LOCATION STATS       // TO STORE THE DATA FROM GITHUB   TEMPORARY
*
* CREATE HOMECONTROLLER // TO CALCULATE THE CASES    TO GET INSTANCES FROM URL
*
* AND CREATE THE TEMPLATE TO DISPLAY IN BROWSER HTML ELEMENT
*
* 
*
*
*
* */

@Service
public class CoronaVirusDataService {

    private static String VIRUS_DATA_URL = "https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_confirmed_global.csv";

    private List<LocationStats> allStats = new ArrayList<>();

    public List<LocationStats> getAllStats() {
        return allStats;
    }

    @PostConstruct //to create instance of class
    @Scheduled(cron = "* * 1 * * *") //Second minute hour day month year (Time to keep our data updated)
    public void fetchVirusData() throws IOException, InterruptedException { //THIS IS INTERFACE WITH ABSTRACT CLASS AND CONSTANTS
        List<LocationStats> newStats = new ArrayList<>();
        HttpClient client = HttpClient.newHttpClient(); //HTTP CLIENT IS ABSTRACT CLASS (class which can not be instanced)
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(VIRUS_DATA_URL)) // we have to convert string to URL
                .build();
        HttpResponse<String> httpResponse = client.send(request, HttpResponse.BodyHandlers.ofString());
        StringReader csvBodyReader = new StringReader(httpResponse.body());
        Iterable<CSVRecord> records = CSVFormat.DEFAULT.withFirstRecordAsHeader().parse(csvBodyReader); //to use CSV FORMAT we imported csv format
        for (CSVRecord record : records) {
            LocationStats locationStat = new LocationStats();
            locationStat.setState(record.get("Province/State"));
            locationStat.setCountry(record.get("Country/Region"));
            int latestCases = Integer.parseInt(record.get(record.size() - 1));
            int prevDayCases = Integer.parseInt(record.get(record.size() - 2));
            locationStat.setLatestTotalCases(latestCases);
            locationStat.setDiffFromPrevDay(latestCases - prevDayCases);

           // System.out.println(locationStat); TO PRINT IN CONSOLE  BUT IT WASNT CLEAR TO READ THE DATA SO WE SWITCHED TO BROWSER
            newStats.add(locationStat);
        }
        this.allStats = newStats;
    }

}
